import { InvalidConfigurationError, InvalidTopicError, PayloadCloneError, UnsupportedEnvironmentError } from "./errors.js";
import { RESERVED_TOPIC_PREFIX } from "./constants.js";
export function assertNonEmpty(value, name) {
    const trimmed = value.trim();
    if (!trimmed) {
        throw new InvalidConfigurationError(`${name} must be a non-empty string.`);
    }
    return trimmed;
}
export function assertPublicTopic(topic) {
    if (!topic.trim() || topic.startsWith(RESERVED_TOPIC_PREFIX)) {
        throw new InvalidTopicError(topic);
    }
}
export function assertExtensionId(id) {
    const normalized = id.trim();
    if (!/^[a-z0-9][a-z0-9._-]*$/i.test(normalized)) {
        throw new InvalidConfigurationError(`Invalid extension id \"${id}\". Use letters, numbers, dots, underscores or dashes.`);
    }
    return normalized;
}
export function createInstanceId() {
    if (typeof crypto === "undefined" || typeof crypto.randomUUID !== "function") {
        throw new UnsupportedEnvironmentError("crypto.randomUUID()");
    }
    return crypto.randomUUID();
}
export function cloneForTransport(value) {
    if (typeof structuredClone !== "function") {
        throw new UnsupportedEnvironmentError("structuredClone()");
    }
    try {
        return structuredClone(value);
    }
    catch (error) {
        throw new PayloadCloneError(error);
    }
}
export function normalizeTarget(target) {
    if (!target) {
        return undefined;
    }
    const instanceId = target.instanceId?.trim();
    const appId = target.appId?.trim();
    if (!instanceId && !appId) {
        throw new InvalidConfigurationError("target must contain a non-empty instanceId or appId.");
    }
    return {
        ...(instanceId ? { instanceId } : {}),
        ...(appId ? { appId } : {})
    };
}
export function matchesTarget(target, identity) {
    if (!target) {
        return true;
    }
    if (target.instanceId && target.instanceId !== identity.instanceId) {
        return false;
    }
    if (target.appId && target.appId !== identity.appId) {
        return false;
    }
    return true;
}
export function freezeIdentity(identity) {
    return Object.freeze({ ...identity });
}
export function freezeTarget(target) {
    return target ? Object.freeze({ ...target }) : undefined;
}
export function toError(value) {
    return value instanceof Error ? value : new Error(String(value));
}
//# sourceMappingURL=utils.js.map