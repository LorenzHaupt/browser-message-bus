import { BUS_NAMESPACE, PROTOCOL_VERSION } from "../core/constants.js";
export function isBridgeHandshakeMessage(value) {
    if (!isRecord(value)) {
        return false;
    }
    if (value.namespace !== BUS_NAMESPACE ||
        value.protocolVersion !== PROTOCOL_VERSION ||
        typeof value.type !== "string" ||
        typeof value.channel !== "string" ||
        typeof value.nonce !== "string" ||
        !isIdentity(value.source)) {
        return false;
    }
    if (value.type === "bridge:hello") {
        return true;
    }
    if (value.type === "bridge:ready") {
        return typeof value.acceptNonce === "string";
    }
    if (value.type === "bridge:connect") {
        return (typeof value.acceptNonce === "string" &&
            typeof value.connectionId === "string" &&
            !!value.connectionId);
    }
    return false;
}
export function isBridgeAck(value) {
    return (isRecord(value) &&
        value.namespace === BUS_NAMESPACE &&
        value.protocolVersion === PROTOCOL_VERSION &&
        value.type === "bridge:ack" &&
        typeof value.connectionId === "string" &&
        !!value.connectionId);
}
function isRecord(value) {
    return typeof value === "object" && value !== null;
}
function isIdentity(value) {
    return (isRecord(value) &&
        typeof value.instanceId === "string" &&
        !!value.instanceId &&
        (value.appId === undefined || (typeof value.appId === "string" && !!value.appId)));
}
//# sourceMappingURL=protocol.js.map