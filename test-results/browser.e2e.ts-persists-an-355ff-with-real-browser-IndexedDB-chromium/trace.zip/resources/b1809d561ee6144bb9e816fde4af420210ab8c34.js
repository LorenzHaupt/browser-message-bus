import { BUS_NAMESPACE, PROTOCOL_VERSION } from "../core/constants.js";
import { isBusEnvelope } from "../core/envelope.js";
import { InvalidEnvelopeError } from "../core/errors.js";
export class MessagePortTransport {
    port;
    connectionId;
    reportError;
    kind = "message-port";
    id;
    receive;
    remoteClose;
    isClosed = false;
    allowedTopics;
    allowedExtensions;
    hasExplicitPolicy;
    constructor(port, connectionId, allowedTopics, allowedExtensions, reportError) {
        this.port = port;
        this.connectionId = connectionId;
        this.reportError = reportError;
        this.id = `bridge:${connectionId}`;
        this.hasExplicitPolicy = allowedTopics !== undefined || allowedExtensions !== undefined;
        if (allowedTopics) {
            this.allowedTopics = new Set(allowedTopics);
        }
        if (allowedExtensions) {
            this.allowedExtensions = new Set(allowedExtensions);
        }
    }
    start(receive, remoteClose) {
        this.receive = receive;
        this.remoteClose = remoteClose;
        this.port.addEventListener("message", this.onMessage);
        this.port.addEventListener("messageerror", this.onMessageError);
        this.port.start();
    }
    send(envelope) {
        if (this.isClosed || !this.isAllowed(envelope)) {
            return;
        }
        const frame = {
            namespace: BUS_NAMESPACE,
            protocolVersion: PROTOCOL_VERSION,
            type: "bridge:envelope",
            connectionId: this.connectionId,
            envelope
        };
        this.port.postMessage(frame);
    }
    close(notifyRemote = true) {
        if (this.isClosed) {
            return;
        }
        this.isClosed = true;
        if (notifyRemote) {
            const frame = {
                namespace: BUS_NAMESPACE,
                protocolVersion: PROTOCOL_VERSION,
                type: "bridge:close",
                connectionId: this.connectionId
            };
            try {
                this.port.postMessage(frame);
            }
            catch {
                // The remote side may already be gone.
            }
        }
        this.port.removeEventListener("message", this.onMessage);
        this.port.removeEventListener("messageerror", this.onMessageError);
        this.port.close();
        this.receive = undefined;
        this.remoteClose = undefined;
    }
    onMessage = (event) => {
        const value = event.data;
        if (!isRecord(value) || value.connectionId !== this.connectionId) {
            return;
        }
        if (value.namespace !== BUS_NAMESPACE ||
            value.protocolVersion !== PROTOCOL_VERSION ||
            typeof value.type !== "string") {
            return;
        }
        if (value.type === "bridge:close") {
            this.isClosed = true;
            this.port.removeEventListener("message", this.onMessage);
            this.port.removeEventListener("messageerror", this.onMessageError);
            this.port.close();
            this.remoteClose?.();
            return;
        }
        if (value.type !== "bridge:envelope" || !isBusEnvelope(value.envelope)) {
            this.reportError(new InvalidEnvelopeError("Bridge received an invalid envelope."), {
                phase: "protocol",
                transportId: this.id
            });
            return;
        }
        if (!this.isAllowed(value.envelope)) {
            return;
        }
        this.receive?.(value.envelope);
    };
    onMessageError = () => {
        this.reportError(new InvalidEnvelopeError("Bridge could not deserialize a message."), {
            phase: "bridge",
            transportId: this.id
        });
    };
    isAllowed(envelope) {
        if (!this.hasExplicitPolicy) {
            return true;
        }
        if (!envelope.system) {
            return this.allowedTopics?.has(envelope.topic) ?? false;
        }
        const extensionId = extensionIdFromSystemTopic(envelope.topic);
        return extensionId !== undefined && (this.allowedExtensions?.has(extensionId) ?? false);
    }
}
function isRecord(value) {
    return typeof value === "object" && value !== null;
}
function extensionIdFromSystemTopic(topic) {
    const prefix = "@bmb/ext/";
    if (!topic.startsWith(prefix)) {
        return undefined;
    }
    const rest = topic.slice(prefix.length);
    const slash = rest.indexOf("/");
    if (slash <= 0) {
        return undefined;
    }
    return rest.slice(0, slash);
}
//# sourceMappingURL=message-port-transport.js.map