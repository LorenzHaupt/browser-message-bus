import { UnsupportedEnvironmentError } from "../core/errors.js";
export class BroadcastChannelTransport {
    channelName;
    reportError;
    kind = "broadcast-channel";
    id;
    channel;
    receive;
    constructor(channelName, reportError) {
        this.channelName = channelName;
        this.reportError = reportError;
        this.id = `broadcast:${channelName}`;
    }
    start(receive) {
        if (this.channel) {
            return;
        }
        if (typeof BroadcastChannel === "undefined") {
            throw new UnsupportedEnvironmentError("BroadcastChannel");
        }
        this.receive = receive;
        this.channel = new BroadcastChannel(this.channelName);
        this.channel.addEventListener("message", this.onMessage);
        this.channel.addEventListener("messageerror", this.onMessageError);
    }
    send(envelope) {
        this.channel?.postMessage(envelope);
    }
    close() {
        if (!this.channel) {
            return;
        }
        this.channel.removeEventListener("message", this.onMessage);
        this.channel.removeEventListener("messageerror", this.onMessageError);
        this.channel.close();
        this.channel = undefined;
        this.receive = undefined;
    }
    onMessage = (event) => {
        this.receive?.(event.data);
    };
    onMessageError = () => {
        this.reportError(new Error("BroadcastChannel could not deserialize a message."), {
            phase: "transport",
            transportId: this.id
        });
    };
}
//# sourceMappingURL=broadcast-channel-transport.js.map