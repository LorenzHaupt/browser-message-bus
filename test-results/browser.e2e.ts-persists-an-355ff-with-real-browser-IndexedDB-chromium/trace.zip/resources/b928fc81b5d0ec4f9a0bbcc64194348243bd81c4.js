import { BrowserMessageBus } from "./core/message-bus.js";
export function createMessageBus(options) {
    return new BrowserMessageBus(options);
}
export { BridgeProtocolError, BridgeSecurityError, BridgeTimeoutError, BusClosedError, DuplicateRequestHandlerError, ExtensionAlreadyInstalledError, InvalidConfigurationError, InvalidEnvelopeError, InvalidTopicError, MessageBusError, PayloadCloneError, PersistenceError, RemoteRequestError, RequestAbortedError, RequestTimeoutError, UnsupportedEnvironmentError } from "./core/errors.js";
//# sourceMappingURL=index.js.map