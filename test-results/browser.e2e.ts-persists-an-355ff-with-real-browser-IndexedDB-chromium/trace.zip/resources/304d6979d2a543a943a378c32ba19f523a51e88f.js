import { DEFAULT_DEDUPE_MAX_ENTRIES, DEFAULT_DEDUPE_TTL_MS } from "./constants.js";
export class DeduplicationCache {
    maxEntries;
    ttlMs;
    seen = new Map();
    constructor(maxEntries = DEFAULT_DEDUPE_MAX_ENTRIES, ttlMs = DEFAULT_DEDUPE_TTL_MS) {
        this.maxEntries = maxEntries;
        this.ttlMs = ttlMs;
    }
    hasOrAdd(id, now = Date.now()) {
        this.cleanup(now);
        if (this.seen.has(id)) {
            return true;
        }
        this.seen.set(id, now);
        if (this.seen.size > this.maxEntries) {
            const oldest = this.seen.keys().next().value;
            if (oldest) {
                this.seen.delete(oldest);
            }
        }
        return false;
    }
    clear() {
        this.seen.clear();
    }
    cleanup(now) {
        const cutoff = now - this.ttlMs;
        for (const [id, timestamp] of this.seen) {
            if (timestamp >= cutoff) {
                break;
            }
            this.seen.delete(id);
        }
    }
}
//# sourceMappingURL=deduplication.js.map