import { BUS_NAMESPACE, DEFAULT_MAX_HOPS, PROTOCOL_VERSION, RESERVED_TOPIC_PREFIX } from "./constants.js";
import { DeduplicationCache } from "./deduplication.js";
import { isBusEnvelope } from "./envelope.js";
import { BusClosedError, ExtensionAlreadyInstalledError, InvalidConfigurationError, InvalidEnvelopeError } from "./errors.js";
import { assertExtensionId, assertNonEmpty, assertPublicTopic, cloneForTransport, createInstanceId, freezeIdentity, freezeTarget, matchesTarget, normalizeTarget } from "./utils.js";
import { BroadcastChannelTransport } from "../transports/broadcast-channel-transport.js";
class ConnectionImpl {
    id;
    remote;
    closeTransport;
    isConnected = true;
    constructor(id, remote, closeTransport) {
        this.id = id;
        this.remote = remote;
        this.closeTransport = closeTransport;
    }
    get connected() {
        return this.isConnected;
    }
    markClosed() {
        this.isConnected = false;
    }
    async close() {
        if (!this.isConnected) {
            return;
        }
        this.isConnected = false;
        await this.closeTransport();
    }
}
export class BrowserMessageBus {
    channel;
    identity;
    instanceId;
    appId;
    maxHops;
    reportErrorHandler;
    dedupe = new DeduplicationCache();
    transports = new Map();
    connections = new Map();
    subscriptions = new Map();
    systemSubscriptions = new Map();
    observers = new Set();
    extensions = new Map();
    isClosed = false;
    constructor(options) {
        this.channel = assertNonEmpty(options.channel, "channel");
        this.maxHops = options.maxHops ?? DEFAULT_MAX_HOPS;
        if (!Number.isInteger(this.maxHops) || this.maxHops < 1 || this.maxHops > 64) {
            throw new InvalidConfigurationError("maxHops must be an integer between 1 and 64.");
        }
        const instanceId = options.instanceId
            ? assertNonEmpty(options.instanceId, "instanceId")
            : createInstanceId();
        const appId = options.appId ? assertNonEmpty(options.appId, "appId") : undefined;
        this.identity = freezeIdentity({
            instanceId,
            ...(appId ? { appId } : {})
        });
        this.instanceId = instanceId;
        if (appId) {
            this.appId = appId;
        }
        this.reportErrorHandler = options.onError ?? defaultErrorHandler;
        const broadcast = new BroadcastChannelTransport(this.channel, this.reportErrorHandler);
        this.registerTransport(broadcast);
    }
    get closed() {
        return this.isClosed;
    }
    publish(topic, ...args) {
        this.assertOpen();
        assertPublicTopic(topic);
        const payload = args[0];
        const options = (args[1] ?? {});
        return this.publishEnvelope(topic, payload, options.target, false);
    }
    subscribe(topic, handler, options = {}) {
        this.assertOpen();
        assertPublicTopic(topic);
        const unsubscribe = this.addSubscription(this.subscriptions, topic, handler);
        if (options.signal) {
            if (options.signal.aborted) {
                unsubscribe();
                return unsubscribe;
            }
            options.signal.addEventListener("abort", unsubscribe, { once: true });
        }
        return unsubscribe;
    }
    use(extension) {
        this.assertOpen();
        const id = assertExtensionId(extension.id);
        if (this.extensions.has(id)) {
            throw new ExtensionAlreadyInstalledError(id);
        }
        const prefix = `${RESERVED_TOPIC_PREFIX}ext/${id}/`;
        const context = {
            channel: this.channel,
            identity: this.identity,
            publish: (topic, payload, options = {}) => this.publishEnvelope(`${prefix}${normalizeExtensionTopic(topic)}`, payload, options.target, true),
            subscribe: (topic, handler) => this.addSubscription(this.systemSubscriptions, `${prefix}${normalizeExtensionTopic(topic)}`, handler),
            observe: handler => {
                this.observers.add(handler);
                return () => this.observers.delete(handler);
            },
            reportError: (error, phase = "extension") => this.reportError(error, { phase })
        };
        const installation = extension.install(context);
        this.extensions.set(id, { installation: installation });
        return installation.api;
    }
    async connect(connector) {
        this.assertOpen();
        const result = await connector.connect({
            channel: this.channel,
            identity: this.identity,
            reportError: this.reportErrorHandler
        });
        this.assertOpen();
        if (this.transports.has(result.transport.id)) {
            await result.transport.close(false);
            throw new InvalidConfigurationError(`A transport with id \"${result.transport.id}\" is already connected.`);
        }
        const connection = new ConnectionImpl(result.transport.id, freezeIdentity(result.remote), () => this.removeTransport(result.transport.id, true));
        this.connections.set(result.transport.id, connection);
        this.registerTransport(result.transport);
        return connection;
    }
    async close() {
        if (this.isClosed) {
            return;
        }
        for (const record of [...this.extensions.values()].reverse()) {
            try {
                await record.installation.dispose?.();
            }
            catch (error) {
                this.reportError(error, { phase: "extension" });
            }
        }
        this.extensions.clear();
        this.isClosed = true;
        for (const connection of this.connections.values()) {
            connection.markClosed();
        }
        this.connections.clear();
        for (const transport of this.transports.values()) {
            try {
                await transport.close(true);
            }
            catch (error) {
                this.reportError(error, { phase: "transport", transportId: transport.id });
            }
        }
        this.transports.clear();
        this.subscriptions.clear();
        this.systemSubscriptions.clear();
        this.observers.clear();
        this.dedupe.clear();
    }
    publishEnvelope(topic, payload, target, system) {
        this.assertOpen();
        const clonedPayload = cloneForTransport(payload);
        const normalizedTarget = freezeTarget(normalizeTarget(target));
        const id = createInstanceId();
        const envelope = {
            namespace: BUS_NAMESPACE,
            protocolVersion: PROTOCOL_VERSION,
            id,
            topic,
            payload: clonedPayload,
            source: this.identity,
            ...(normalizedTarget ? { target: normalizedTarget } : {}),
            timestamp: Date.now(),
            hop: 0,
            system
        };
        this.dedupe.hasOrAdd(id, envelope.timestamp);
        this.observe(envelope);
        this.deliverLocally(envelope);
        this.forward(envelope);
        return { messageId: id };
    }
    registerTransport(transport) {
        this.transports.set(transport.id, transport);
        try {
            const startResult = transport.start(envelope => this.receive(envelope, transport.id), () => void this.removeTransport(transport.id, false));
            if (startResult instanceof Promise) {
                void startResult.catch(error => {
                    this.reportError(error, { phase: "transport", transportId: transport.id });
                });
            }
        }
        catch (error) {
            this.transports.delete(transport.id);
            throw error;
        }
    }
    async removeTransport(id, notifyRemote) {
        const transport = this.transports.get(id);
        if (!transport) {
            return;
        }
        this.transports.delete(id);
        const connection = this.connections.get(id);
        connection?.markClosed();
        this.connections.delete(id);
        try {
            await transport.close(notifyRemote);
        }
        catch (error) {
            this.reportError(error, { phase: "transport", transportId: id });
        }
    }
    receive(value, incomingTransportId) {
        if (this.isClosed) {
            return;
        }
        if (!isBusEnvelope(value)) {
            this.reportError(new InvalidEnvelopeError(), {
                phase: "protocol",
                transportId: incomingTransportId
            });
            return;
        }
        if (value.hop > this.maxHops) {
            return;
        }
        if (this.dedupe.hasOrAdd(value.id)) {
            return;
        }
        this.observe(value);
        this.deliverLocally(value);
        if (value.hop >= this.maxHops) {
            return;
        }
        this.forward({ ...value, hop: value.hop + 1 }, incomingTransportId);
    }
    deliverLocally(envelope) {
        if (!matchesTarget(envelope.target, this.identity)) {
            return;
        }
        const registry = envelope.system ? this.systemSubscriptions : this.subscriptions;
        const subscriptions = registry.get(envelope.topic);
        if (!subscriptions?.size) {
            return;
        }
        for (const subscription of subscriptions) {
            if (!subscription.active) {
                continue;
            }
            const payloadSnapshot = cloneForTransport(envelope.payload);
            const context = createMessageContext(envelope);
            subscription.queue = subscription.queue
                .then(async () => {
                if (!subscription.active) {
                    return;
                }
                await subscription.handler(payloadSnapshot, context);
            })
                .catch(error => {
                this.reportError(error, { phase: "subscriber", topic: envelope.topic });
            });
        }
    }
    forward(envelope, excludeTransportId) {
        for (const transport of this.transports.values()) {
            if (transport.id === excludeTransportId) {
                continue;
            }
            try {
                transport.send(envelope);
            }
            catch (error) {
                this.reportError(error, {
                    phase: "transport",
                    topic: envelope.topic,
                    transportId: transport.id
                });
            }
        }
    }
    observe(envelope) {
        if (envelope.system || this.observers.size === 0) {
            return;
        }
        for (const observer of this.observers) {
            const message = {
                topic: envelope.topic,
                payload: cloneForTransport(envelope.payload),
                context: createMessageContext(envelope)
            };
            try {
                observer(message);
            }
            catch (error) {
                this.reportError(error, { phase: "extension", topic: envelope.topic });
            }
        }
    }
    addSubscription(registry, topic, handler) {
        let bucket = registry.get(topic);
        if (!bucket) {
            bucket = new Set();
            registry.set(topic, bucket);
        }
        const subscription = {
            active: true,
            queue: Promise.resolve(),
            handler
        };
        bucket.add(subscription);
        return () => {
            if (!subscription.active) {
                return;
            }
            subscription.active = false;
            bucket?.delete(subscription);
            if (bucket?.size === 0) {
                registry.delete(topic);
            }
        };
    }
    reportError(error, context) {
        try {
            this.reportErrorHandler(error, context);
        }
        catch {
            // An error reporter must never break message delivery.
        }
    }
    assertOpen() {
        if (this.isClosed) {
            throw new BusClosedError();
        }
    }
}
function createMessageContext(envelope) {
    const source = freezeIdentity(envelope.source);
    const target = freezeTarget(envelope.target);
    return Object.freeze({
        messageId: envelope.id,
        source,
        ...(target ? { target } : {}),
        timestamp: envelope.timestamp
    });
}
function normalizeExtensionTopic(topic) {
    const value = topic.trim();
    if (!value || value.startsWith("/") || value.includes("..")) {
        throw new InvalidConfigurationError(`Invalid extension topic \"${topic}\".`);
    }
    return value;
}
function defaultErrorHandler(error, context) {
    console.error("[browser-message-bus]", context, error);
}
//# sourceMappingURL=message-bus.js.map