import { InvalidConfigurationError } from "../core/errors.js";
import { windowBridge } from "./window-bridge.js";
export function iframeBridge(options) {
    const targetWindow = options.iframe.contentWindow;
    if (!targetWindow) {
        throw new InvalidConfigurationError("The iframe does not have a contentWindow yet.");
    }
    return windowBridge({
        targetWindow,
        mode: "connect",
        origin: options.origin,
        ...(options.timeoutMs !== undefined ? { timeoutMs: options.timeoutMs } : {}),
        ...(options.allowedTopics ? { allowedTopics: options.allowedTopics } : {}),
        ...(options.allowedExtensions ? { allowedExtensions: options.allowedExtensions } : {}),
        ...(options.localWindow ? { localWindow: options.localWindow } : {})
    });
}
//# sourceMappingURL=iframe-bridge.js.map