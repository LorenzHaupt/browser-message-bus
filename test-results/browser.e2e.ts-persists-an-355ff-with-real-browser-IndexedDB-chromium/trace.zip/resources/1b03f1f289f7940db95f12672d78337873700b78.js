export { persistentLog } from "./extensions/persistent-log.js";
//# sourceMappingURL=persistent-log.js.map